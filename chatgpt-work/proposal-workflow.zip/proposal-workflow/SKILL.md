---
name: proposal-workflow
description: "Run or resume a written competition proposal in ChatGPT Work. Route a business case, business plan, innovation essay, or hybrid brief to the relevant skills for scope, brainstorming, evidence, writing, charts, appendices, production, and review. Use for the whole submission or an authorized phase."
---

# Proposal Workflow

Deliver the requested work at its intended depth. One entry point selects the competition track and useful methods. Read only the materials needed for the current decision or deliverable.

## Start with the actual request

1. Read the brief, rubric, page limits, required files, author comments, and project decisions already available. Identify the intended reader and requested action: explore, decide, draft, revise, produce, or review. The user controls the work and its scope. Official rules determine submission compliance. Current user instructions and explicit case decisions guide style. Prior examples calibrate judgment.
2. Hold the full request in view. Track required parts, the reasoning each needs, the evidence that supports it, and what form the finished result must take. Compress repeated material before compression of reasoning. Preserve working content, approved names, idea scope, and practical ambition. A plan or pilot should never silently replace an authorized complete deliverable.
3. Ask a short, consolidated round of questions only for unresolved choices that materially change the scope, design, conclusions, financial results, or interpretation. Use supplied sources before asking. Continue independent work while a consequential answer is pending. Resolve routine wording, format, fit, and reversible production choices directly. Honor explicit planning-only or hold instructions.
4. Select the track automatically when the brief makes it clear. For a hybrid, choose the track that answers the primary judging question and borrow only the needed methods from another track. Ask only if the choice materially changes the submission. For a different written competition genre, use the shared skills and the official rubric. Do not require the user to choose modules.

| Request or dependency | Open |
|---|---|
| Rubric, format, scope or assumptions | [Competition Brief and Scope](bank/skills/competition-brief-and-scope/GUIDE.md) |
| Business case for an incumbent or client decision | [Business Case Competition](bank/skills/business-case-competition/GUIDE.md) |
| Venture viability, paying customers and operations | [Business Plan Competition](bank/skills/business-plan-competition/GUIDE.md) |
| Literature-grounded innovation essay | [Innovation Essay](bank/skills/innovation-essay/GUIDE.md) |
| Idea still open or a consequential weakness emerged | [Competition Brainstorming](bank/skills/competition-brainstorming/GUIDE.md) |
| Diagnosis, solution in use, and recommendation | [Proposal Strategy and Argument](bank/skills/proposal-strategy-and-argument/GUIDE.md) |
| Claim support, case research, or sourcing | [Research, Evidence, and Citations](bank/skills/research-evidence-and-citations/GUIDE.md) |
| Prose, language calibration, or comments | [Writing and Editing](bank/skills/writing-and-editing/GUIDE.md) |
| Delivery, risk, finance, or outcome measures | [Implementation, Impact, and Feasibility](bank/skills/implementation-impact-and-feasibility/GUIDE.md) |
| Chart selection, precise figures, or editable render | [Charts, Figures, and Tables](bank/skills/charts-figures-and-tables/GUIDE.md) |
| Document layout, hyperlinks, or final file production | [Appendices and Document Production](bank/skills/appendices-and-document-production/GUIDE.md) |
| Full release review or scoped revision check | [Judge Review and Final Checks](bank/skills/judge-review-and-final-checks/GUIDE.md) |
| Material capability gap | [Find and Use Tools](bank/skills/find-and-use-tools/GUIDE.md) |
| Editable BCC deck, explicitly requested | [Case Deck Design](bank/skills/case-deck-design/GUIDE.md) |

In the repository, use the sibling skill paths. In the single-entry Work upload, onboarding rewrites the paths to bundled guides. If running this entry on its own, ask for the private bank only when missing instructions block a material part of the request. Read the [reference index](bank/references/README.md) for voice and case calibration. Full examples are for how the argument reads and how the document works. They do not source a new project's factual claims.

## Complete the authorized work

- **Explore.** Develop the user's initial idea first. Explain any substantive weakness using the actual brief and evidence before introducing alternatives. When the real choice is open, compare credible directions against the same criteria and say what changes with each.
- **Build the argument.** Establish the problem and causal links, describe the complete solution in use, and work backward to owners, capabilities, costs, risks, measures, and timing. Choose appropriate exhibits alongside the argument. Keep essential reasoning in the body. Label real material uncertainty precisely where it matters.
- **Make the deliverable.** For a production request, create the actual audience file. Preserve the genre's structure. In a main proposal use wide, shallow charts when they remain legible. In an appendix, choose geometry for inspection and pack sections continuously where possible. In revisions, inspect each comment with its passage and ask before applying it beyond the agreed scope.
- **Review and verify.** Use the scored loop automatically for full submissions, with an independent critic when available and scoped appropriately. For a narrow edit, check changes and relevant regressions. Inspect the actual final rendering and the meaningful destinations of evidence links. Never imply a check ran simply because the proposed workflow includes it.
- **Hand off.** Provide the result and any material unresolved limitation in brief. Keep assistant commentary, ratings, critic exchanges, tool details, and internal provenance out of audience files. Retain a compact private record of decisions, sources, assumptions, and unresolved items if continuity would be valuable or was requested.

This workflow adapts brainstorming, scoped execution, review, and verification ideas from [obra/Superpowers](https://github.com/obra/superpowers/tree/22f0b463e7a5e579904dd6211a520321035526f7). Use those ideas proportionately for competition work. Software-specific planning ceremonies, worktrees, and mandatory coding stages are not prerequisites for writing a proposal.
